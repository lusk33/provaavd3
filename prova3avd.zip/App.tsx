import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useRef, useState } from 'react';
import { FlatList, StyleSheet, TouchableOpacity, Text, TextInput, View } from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';

interface IPaises {
  identificacao: string,
  nome: string,
}

export default function App() {
  const [nome, setNome] = useState('');
  const [identificacao, setIdentificacao] = useState('');

  const [paises, setPaises] = useState<IPaises[]>([]);

  useEffect(() => {
    async function loadData() {
      const dado = await AsyncStorage.getItem('@paisesStorage');
      if (dado) {
        setPaises(JSON.parse(dado));
      }
    }
    loadData();
  }, []);

  useEffect(() => {
    async function saveData() {
      await AsyncStorage.setItem('@paisesStorage', JSON.stringify(paises));
    }
    saveData();
  }, [paises]);


  function addPais() {
    if (nome && identificacao) {
      setPaises([...paises, { identificacao, nome }]);
      setNome("");
    }
  }

  function deletePais(identificacao: string) {
    const items = paises.filter(pais => pais.identificacao !== identificacao);
    setPaises(items);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Cadastro de Países</Text>
      <Text style={styles.subtitulo}>Insira abaixo um ID único para identificarmos seu país.</Text>
      <Text style={styles.subtitulo}> Em seguida entre com o nome do país desejado.</Text>
      <Text style={styles.subtitulo}> Para apagar o item, basta clicar nele.</Text>

      <TextInput
        style={styles.input}
        placeholder="Qual ID você deseja?"
        onChangeText={text => setIdentificacao(text)}
        defaultValue={identificacao}
      />
      <TextInput
        style={styles.input}
        placeholder="Qual o nome do país?"
        onChangeText={text => setNome(text)}
        defaultValue={nome}
      />
      <TouchableOpacity
        style={styles.button}
        onPress={addPais}
      >
        <Text style={styles.cor_de_fundo} >Salvar</Text>
      </TouchableOpacity>
      <Text style={styles.titulo}>Países Cadastrados</Text>

      {
        paises.map(pais =>
          <TouchableOpacity
            key={pais.identificacao}
            onPress={() => { deletePais(pais.identificacao) }}
          >
            <Text style={styles.nomepais} >{pais.identificacao} - {pais.nome}</Text>
          </TouchableOpacity>
        )
      }

    </View>
  );
} ''

const styles = StyleSheet.create({

  input: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderColor: 'black',
    borderWidth: 1,
    borderStyle: 'solid',
    borderRadius: 16,
    color: '#000',
    backgroundColor: '#fff',
    marginVertical: 30,
    width: '90%'
  },
  button: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#32E35B',
    borderColor: '#fff',
    borderWidth: 1,
    borderStyle: 'solid',
    borderRadius: 16,
    marginVertical: 20,
    width: '50%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',

  },
  nomepais: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#32E35B',
    borderColor: '#fff',
    borderWidth: 1,
    borderStyle: 'solid',
    borderRadius: 16,
    marginVertical: 20,
    width: 'auto',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',

  },
  titulo: {
    fontSize: 30,
    color: '#357A39'
  },
  subtitulo: {
    paddingVertical: 10,
    fontSize: 15,
    color: '#357A39'
  },
  container: {
    flex: 1,
    backgroundColor: '#B6FABA',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 100
  },
  cor_de_fundo: {
    color: '#fff'
  },
});
